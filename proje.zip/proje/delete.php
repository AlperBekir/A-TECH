<?php
include 'databaseconnection.php';

if (isset($_GET['id'])) {

    $result = mysqli_query($con, "DELETE FROM product WHERE product_id=" . $_GET['id']);
    if ($result == true)
        echo "sucess";
    header("Location:table.php");
}

?>