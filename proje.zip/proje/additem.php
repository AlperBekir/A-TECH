<?php

include 'databaseconnection.php';

$item_name = "";
$item_price = "";


if (isset($_POST['add'])) {
  echo "connect";
  $item_name = mysqli_real_escape_string($con, $_POST['product_name']);
  $item_price = mysqli_real_escape_string($con, $_POST['price']);
  $quant = mysqli_real_escape_string($con, $_POST['quant']);

  $query = "INSERT INTO product (product_name,price,quantity) 
  			  VALUES('$item_name','$item_price','$quant')";
  if (mysqli_query($con, $query)) {
    echo "<script>alert('Successfully stored');</script>";

  } else {
    echo "<script>alert('Somthing wrong!!!');</script>";
  }

  require('./table.php');

}
?>