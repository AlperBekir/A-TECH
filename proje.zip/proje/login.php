<?php
include 'databaseconnection.php';
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "select * from user where email = '$email' and password = '$password'";
$result = mysqli_query($con, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);

if ($count == 1) {
    require("./table.php");
} else {
    echo "<h1> Login Failed.</h1>";
}
?>